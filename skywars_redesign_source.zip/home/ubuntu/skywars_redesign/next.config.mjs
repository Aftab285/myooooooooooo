/** @type {import("next").NextConfig} */
const nextConfig = {
  output: "export",
  // Optional: Add other configurations here if needed
  // For example, if you have images in /public/images and want them to be served correctly:
  // images: {
  //   unoptimized: true,
  // },
};

export default nextConfig;

