import Link from "next/link";

export default function HomePage() {
  return (
    <div className="relative flex flex-col min-h-screen items-center justify-center overflow-hidden">
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute z-0 w-auto min-w-full min-h-full max-w-none"
      >
        <source src="/videos/landing_video.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="absolute inset-0 bg-black opacity-50 z-10"></div> {/* Overlay */}
      <div className="relative z-20 flex flex-col items-center justify-center text-center p-4">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
          Advanced Drone Detection Solutions
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl">
          Protecting your airspace with cutting-edge technology. Skywars offers comprehensive drone detection services to ensure safety and security.
        </p>
        <Link href="#services" legacyBehavior>
          <a className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300">
            Explore Services
          </a>
        </Link>
      </div>

      {/* Placeholder for Services Section */}
      <section id="services" className="relative z-20 w-full py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Service Item 1 */}
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-semibold mb-3">Real-time Monitoring</h3>
              <p className="text-gray-300">
                Continuous, 24/7 surveillance of your airspace to detect and identify unauthorized drone activity instantly.
              </p>
            </div>
            {/* Service Item 2 */}
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-semibold mb-3">Threat Assessment</h3>
              <p className="text-gray-300">
                Advanced analytics to assess the threat level of detected drones and provide actionable intelligence.
              </p>
            </div>
            {/* Service Item 3 */}
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-semibold mb-3">Custom Solutions</h3>
              <p className="text-gray-300">
                Tailored drone detection systems designed to meet the specific security needs of your facility or event.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Placeholder for About Us Section */}
       <section id="about" className="relative z-20 w-full py-16 bg-gray-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">About Skywars</h2>
          <p className="text-lg md:text-xl text-gray-300 mb-6 max-w-3xl mx-auto">
            Skywars is a leader in drone detection technology, committed to providing innovative and reliable solutions for a safer airspace. Our team of experts leverages cutting-edge technology to deliver unparalleled protection against aerial threats.
          </p>
        </div>
      </section>

      {/* Placeholder for Contact Section */}
      <section id="contact" className="relative z-20 w-full py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Contact Us</h2>
          <form className="max-w-xl mx-auto">
            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-300 mb-2">Name</label>
              <input type="text" id="name" name="name" className="w-full p-3 rounded-lg bg-gray-800 border border-gray-700 focus:outline-none focus:border-blue-500" />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
              <input type="email" id="email" name="email" className="w-full p-3 rounded-lg bg-gray-800 border border-gray-700 focus:outline-none focus:border-blue-500" />
            </div>
            <div className="mb-6">
              <label htmlFor="message" className="block text-gray-300 mb-2">Message</label>
              <textarea id="message" name="message" rows={4} className="w-full p-3 rounded-lg bg-gray-800 border border-gray-700 focus:outline-none focus:border-blue-500"></textarea>
            </div>
            <div className="text-center">
              <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300">
                Send Message
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-20 w-full py-8 bg-gray-950 text-center text-gray-400">
        <p>&copy; {new Date().getFullYear()} Skywars Drone Detection. All rights reserved.</p>
        <p className="text-sm">Based on the original Skywars.blue</p>
      </footer>
    </div>
  );
}

